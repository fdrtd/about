network_definition = {
    'nodes': [
        'https://lrz.fdrtd.com/public1',
        'https://lrz.fdrtd.com/public2',
        'https://lrz.fdrtd.com/public3'
    ],
    'central': 'https://lrz.fdrtd.com/public4',
    'sync': 'https://lrz.fdrtd.com/public5'
}
