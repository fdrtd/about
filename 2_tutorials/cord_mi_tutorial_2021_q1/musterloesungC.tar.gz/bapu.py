# prepare the data

table = [
    ['Einrichtungsidentifikator', 'AngabeDiag1', 'AngabeDiag2', 'AngabeGeschlecht', 'AngabeAlter', 'Anzahl'],
    ['260123452-Bapu', 'E84,-', 'O80', 'f', '(11,20]', 2],
    ['260123452-Bapu', 'E84,-', 'O80', 'f', '(21,30]', 2],
    ['260123452-Bapu', 'E84,-', 'O80', 'f', '(31,40]', 2],
    ['260123452-Bapu', 'E84,-', 'O80', 'f', '(41,50]', 2]
]

data = [anzahl for (_, _, _, _, _, anzahl) in table[1:]]


# do the calculation

import fdrtd
from network_definition import network_definition

my_network_definition = {
    **network_definition,
    'myself': 1
}

my_api = fdrtd.HighLevelApi(network_definition=my_network_definition,
                            tokens=['CORD-MI workshop', '<something>'])

print(my_api.compute(protocol='fdrtd-simon',
                     microservice='basic-sum',
                     data=data))
