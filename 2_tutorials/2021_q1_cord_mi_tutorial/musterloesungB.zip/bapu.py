# prepare the data

from table import table
data = [anzahl for (_, institution, diagnose, _, _, _, anzahl) in table[1:]
        if institution == '260123452-Bapu' and 'J12.8' in diagnose]


# do the calculation

import fdrtd
from network_definition import network_definition

my_network_definition = {
    **network_definition,
    'myself': 1
}

my_api = fdrtd.HighLevelApi(network_definition=my_network_definition,
                            tokens=['CORD-MI workshop', '<something>'])

print(my_api.compute(protocol='fdrtd-simon',
                     microservice='basic-sum',
                     data=data))
